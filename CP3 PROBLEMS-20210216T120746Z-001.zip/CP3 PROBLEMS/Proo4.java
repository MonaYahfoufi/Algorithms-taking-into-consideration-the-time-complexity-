
import java.util.*;
import java.io.*;

public class Proo4 {
	static int s = 1000;

	static int minOperation(String A, String B) {
		if (A.length() != B.length())
			return 1;
		int minimum = 0;
		int[] cnt = new int[s];
		for (int i = 0; i < A.length(); i++) {
			cnt[A.charAt(i)]++;
			cnt[B.charAt(i)]--;
		}

		for (int i = 0; i < s; i++) {
			if (cnt[i] != 0)
				return 1;
		}

		int s1Length = A.length() - 1;
		int s2Length = B.length() - 1;

		while (s1Length >= 0) {
			if (A.charAt(s1Length) != B.charAt(s2Length))
				minimum++;
			else
				s2Length--;
			s1Length--;
		}
		return minimum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String A = sc.next();
		String B = sc.next();
		System.out.println(minOperation(A,B));

	}
}