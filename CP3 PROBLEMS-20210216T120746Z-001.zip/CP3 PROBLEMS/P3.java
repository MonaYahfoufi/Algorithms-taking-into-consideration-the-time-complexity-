import java.util.*;
public class P3 {
	 static Scanner scan=new Scanner(System.in);
	  static int N= scan.nextInt();
	 static void printboard(int board[][]) {	
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) 
				if(board[i][j]==1) {
					System.out.print("1 ");
				}
				else {
					System.out.print("0 ");
				}
				System.out.println();
			}
	}
		static boolean topnotp(int board[][],int row,int colomun) {
			int i;
			for( i=0;i<colomun;i++) {
				if(board[row][i]==1) 
					return false;
				}
			int j;
			for( i=row, j = colomun; i >= 0 && j >= 0; i--,j-- ) {
				if(board[i][j]==1)
					return false;
			}
			return true;
		}
		
		 static boolean boardsolver(int board[][], int colomun) {
			if(colomun>= N) 
				return true;
			for(int i=0;i<N;i++) {
				if(topnotp(board, i, colomun)) {
					board[i][colomun]=1;
					if(boardsolver(board, colomun+1)) 
						return true;
						board[i][colomun]=0;
				}
			}
			return false;
			
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int board [][]=new int[N][N];
		if(!boardsolver(board, 0)) {
			System.out.println("no solution");
		}
		printboard(board);
}
}

