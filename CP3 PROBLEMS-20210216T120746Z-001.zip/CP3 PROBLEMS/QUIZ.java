
import java.util.*;
public class QUIZ 
{ 
    public static int max(int m, int n) { 
    	if (m > n) {
    		return m;
    	}
    	else {
    		return n;
    	}
    	} 
       
    public static int knapSack(int W, int wi[], int vi[], int z) 
    { 
     int i, p; 
     int M[][] = new int[z+1][W+1]; 
       
     for (i = 0; i <= z; i++) 
     { 
         for (p = 0; p <= W; p++) 
         { 
             if (i==0 || p==0) 
                  M[i][p] = 0; 
             else if (wi[i-1] <= p) 
                   M[i][p] = max(vi[i-1] + M[i-1][p-wi[i-1]],  M[i-1][p]); 
             else
                   M[i][p] = M[i-1][p]; 
         } 
      } 
       
      return M[z][W]; 
    } 
  
    
    public static void main(String args[]) 
    { 
    	Scanner scan=new Scanner(System.in);
    	int size=scan.nextInt();
        int vi[] = new int[size];
        for(int i=0;i<size;i++) {
        	vi[i]=scan.nextInt();
        }
        int wi[] = new int[size];
        for(int i=0;i<size;i++) {
        	wi[i]=scan.nextInt();
        }
        int  W = scan.nextInt(); 
        int n = vi.length; 
        System.out.println();
        System.out.println(knapSack(W, wi, vi, n)); 
       
    } 
} 