import java.util.*;
public class PP1
{ 
 
    public static int MS(int arr[], int n) 
    { 
        int i, j, max = 0; 
        int maxsum[] = new int[n]; 
  
        for (i = 0; i < n; i++) 
            maxsum[i] = arr[i]; 
       
        for (i = 1; i < n; i++) 
            for (j = 0; j < i; j++) 
                if (arr[i] > arr[j] && maxsum[i] < maxsum[j] + arr[i]) 
                    maxsum[i] = maxsum[j] + arr[i]; 
  
        for (i = 0; i < n; i++) 
            if (max < maxsum[i]) 
            		max = maxsum[i]; 
  
        return max; 
    } 
  
    public static void main(String args[]) 
    { 
    	Scanner scan=new Scanner(System.in);
    	int size=scan.nextInt();
        int arr[] = new int[size];
        for(int i=0;i<arr.length;i++) {
        	arr[i]=scan.nextInt();
        }
        System.out.println(MS(arr, size)); 
    } 
} 
